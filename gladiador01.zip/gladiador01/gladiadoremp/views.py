from django.shortcuts import render
from django.views.generic import DateDetailView

def index(request):
    return render(request, "global/index.html")

def elenco(request):
    return render(request, "partial/elenco.html")

def footer(request):
    return render(request, "partial/footer.html")

def header(request):
    return render(request, "partial/header.html")

def home(request):
    return render(request, "partial/home.html")

def enredo(request):
    return render(request, "partial/enredo.html")

def welcome(request):
    return render(request, "partial/welcome.html")