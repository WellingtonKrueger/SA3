from django.urls import path
from gladiadoremp.views import index, elenco, enredo, footer, header, home, welcome

urlpatterns = [
    path('', index),  # Adicione esta linha para corresponder à raiz e redirecionar para a visualização 'index'
    path('elenco', elenco),
    path('enredo', enredo),
    path('footer', footer),
    path('header', header),
    path('home', home),
    path('welcome', welcome),

]